Distributed here is a basic font set, as it seems very difficult to be sure
what any given machine has.
The 'Liberation' font set from Red Hat is clearly and openly GPL, unlike almost all other 'free' fonts I could find on the web. Only the sans-serif set is included here, for space. 
The full distribution includes a plain serif and monospace also.

You can place any font of your choice into either this directory or your sites files/fonts directory (create it if it doesn't exist), and use it from there.