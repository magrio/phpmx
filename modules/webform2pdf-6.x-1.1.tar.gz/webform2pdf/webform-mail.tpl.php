<?php
include drupal_get_path('module', 'webform2pdf') . '/webform2pdf-mail.tpl.php';

include drupal_get_path('module', 'webform') . '/webform-mail.tpl.php';
