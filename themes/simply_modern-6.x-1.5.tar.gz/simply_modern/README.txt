;$Id;

Simply Modern features and description: http://www.tributemedia.com/drupal_community/themes/simply_modern
Simply Modern Support Forum: http://www.tributemedia.com/forum/simply_modern
